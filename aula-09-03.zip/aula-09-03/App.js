import { StyleSheet, Text, View } from 'react-native';
import CustomButton from './components/customButton/CustomButton';
import TextInputBox from './components/textInputBox/TextInputBox';
import { ScrollView, StatusBar } from 'react-native-web';
import React, { useState } from 'react';
import funcaoSoma from './services/funcaoSoma';
import funcaoSubtracao from './services/funcaoSubtracao';
import funcaoDivisao from './services/funcaoDivisao';
import funcaoMultiplicacao from './services/funcaoMultiplicacao';
import funcaoMedia from './services/funcaoMedia';
import Logo from './components/logo/Logo';

export default function App() {
  const [number1, setNumber1] = useState('');
  const [number2, setNumber2] = useState('');
  const [number3, setNumber3] = useState('');
  const [resp, setResp] = useState('');

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.container}>
        <Logo />
        <Text>Calcular Média do Aluno</Text>
        <TextInputBox value={number1} onChangeText={setNumber1} placeholder="1° nota: " keyboardType='numeric' />
        <StatusBar style='auto'></StatusBar>

        <TextInputBox value={number2} onChangeText={setNumber2} placeholder="2° nota: " keyboardType='numeric' />
        <StatusBar style='auto'></StatusBar>

        <TextInputBox value={number3} onChangeText={setNumber3} placeholder="3° nota: " keyboardType='numeric' />
        <StatusBar style='auto'></StatusBar>

        <CustomButton
          title="Calcular Média"
          onPress={() => funcaoMedia(number1, number2, number3, setResp)}
          style={{ backgroundColor: '#000' }}
        />

        <Text>Nota: {resp}</Text>
        <StatusBar style="auto"></StatusBar>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
