export default function funcaoSubtracao(number1, number2, setResp) {
    const sub = parseFloat(number1) - parseFloat(number2);

    if(isNaN(sub)) {
        setResp(0);
    } else {
        setResp(sub);
    }
}