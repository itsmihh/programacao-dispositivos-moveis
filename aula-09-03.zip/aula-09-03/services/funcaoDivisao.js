export default function funcaoDivisao(number1, number2, setResp) {
    const div = parseFloat(number1) / parseFloat(number2);

    if(isNaN(div)) {
        setResp(0);
    } else {
        setResp(div);
    }
}