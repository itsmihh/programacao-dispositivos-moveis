export default function funcaoMultiplicacao(number1, number2, setResp) {
    const mult = parseFloat(number1) * parseFloat(number2);

    if(isNaN(mult)){
        setResp(0);
    } else{
        setResp(mult);
    }
}