import { StyleSheet, Text, View } from 'react-native';
import CustomButton from './components/customButton/CustomButton';
import TextInputBox from './components/textInputBox/TextInputBox';
import { StatusBar } from 'react-native-web';
import React, { useState } from 'react';
import funcaoSoma from './services/funcaoSoma';

export default function App() {
  const [number1, setNumber1] = useState('');
  const [number2, setNumber2] = useState('');
  const [resp, setResp] = useState(0);

  return (
    <View style={styles.container}>
      <Text>Soma</Text>
      <TextInputBox value={number1} onChangeText={setNumber1} placeholder="Digite o primeiro numero" keyboardType='numeric'/>
      <StatusBar style='auto'></StatusBar>

      <TextInputBox value={number2} onChangeText={setNumber2} placeholder="Digite o segundo numero" keyboardType='numeric'/>
      <StatusBar style='auto'></StatusBar>

      <CustomButton
        title="Calcular" 
        onPress={() => funcaoSoma(number1, number2,setResp)}
        style={{ backgroundColor: '#fda300'}}
      />

      <Text>Resultado {resp}</Text>
    <StatusBar style="auto"></StatusBar>      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
