import { StyleSheet, Text, View } from 'react-native';
import CustomButton from './components/customButton/CustomButton';
import TextInputBox from './components/textInputBox/TextInputBox';
import { StatusBar } from 'react-native-web';
import React, { useState } from 'react';
import funcaoSoma from './services/funcaoSoma';
import funcaoSubtracao from './services/funcaoSubtracao';
import funcaoDivisao from './services/funcaoDivisao';
import funcaoMultiplicacao from './services/funcaoMultiplicacao';

export default function App() {
  const [number1, setNumber1] = useState('');
  const [number2, setNumber2] = useState('');
  const [resp, setResp] = useState(0);

  return (
    <View style={styles.container}>
      <Text>Soma</Text>
      <TextInputBox value={number1} onChangeText={setNumber1} placeholder="Digite o primeiro numero" keyboardType='numeric'/>
      <StatusBar style='auto'></StatusBar>

      <TextInputBox value={number2} onChangeText={setNumber2} placeholder="Digite o segundo numero" keyboardType='numeric'/>
      <StatusBar style='auto'></StatusBar>

      <CustomButton
        title="Somar" 
        onPress={() => funcaoSoma(number1, number2,setResp)}
        style={{ backgroundColor: '#fda300'}}
      />

      <CustomButton
        title="Subtrair" 
        onPress={() => funcaoSubtracao(number1, number2,setResp)}
        style={{ backgroundColor: '#fdf900ff'}}
      />

      <CustomButton
        title="Dividir" 
        onPress={() => funcaoDivisao(number1, number2,setResp)}
        style={{ backgroundColor: '#00fd7aff'}}
      />

      <CustomButton
        title="Multiplicar" 
        onPress={() => funcaoMultiplicacao(number1, number2,setResp)}
        style={{ backgroundColor: '#0076fdff'}}
      />

      <Text>Resultado {resp}</Text>
    <StatusBar style="auto"></StatusBar>      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
