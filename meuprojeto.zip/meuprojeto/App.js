// import React from 'react';
// import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import CustomButton from './components/customButton/CustomButton';
import TextInputBox from './components/textInputBox/TextInputBox';
import { StatusBar } from 'react-native-web';

export default function App() {
  return (
    <View style={styles.container}>
      <Text>Open up App.js to start working on your app!</Text>
      <CustomButton
        title="Press me" 
        onPress={() => alert('Button pressed')}
        style={{ backgroundColor: '#fda300'}}
      />
      <TextInputBox placeholder="Digite" keyboardType='numeric'/>
      <StatusBar style='auto'></StatusBar>
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
